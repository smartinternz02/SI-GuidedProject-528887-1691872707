# SI-GuidedProject-415944-1670220922
SMS Spam Detection
Over recent years, as the popularity of mobile phone devices has increased, Short Message Service (SMS) has grown into a multi-billion dollar industry.
At the same time, reduction in the cost of messaging services has resulted in growth in unsolicited commercial advertisements (spams) being sent to mobile phones.
Due to Spam SMS, Mobile service providers suffer from some sort of financial problems as well as it reduces calling time for users. 
Unfortunately, if the user accesses such Spam SMS they may face the problem of virus or malware. 
When SMS arrives at mobile it will disturb mobile user privacy and concentration. 
It may lead to frustration for the user. So Spam SMS is one of the major issues in the wireless communication world and it grows day by day.
demo link :https://drive.google.com/file/d/1aIawn_QjwSDx5Dvi4N6gJ2fhNGWcKuc0/view?usp=share_link
